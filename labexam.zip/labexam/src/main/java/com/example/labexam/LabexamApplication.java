package com.example.labexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabexamApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabexamApplication.class, args);
		
	}

}
