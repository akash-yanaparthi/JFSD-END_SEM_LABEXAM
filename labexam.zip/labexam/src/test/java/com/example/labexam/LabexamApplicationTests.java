package com.example.labexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabexamApplicationTests {

	@Test
	void contextLoads() {
	}

}
